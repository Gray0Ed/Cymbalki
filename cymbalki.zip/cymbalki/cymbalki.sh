#!/bin/bash
java -jar -Djava.library.path="native_libs/" cymbalki.jar
